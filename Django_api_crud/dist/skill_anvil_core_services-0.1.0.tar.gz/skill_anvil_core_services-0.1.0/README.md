# core-services

Reusable class-based service layer for Django apps.
